#include "shell.h"

int main() {

    shell::runShell();
    return 0;
}

