compiled on raspbian using g++ 4.8

Fabio Gottlicher, A01647928