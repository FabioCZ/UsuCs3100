#sample run with 4 cpus, 5 ios, 3.3 sec context switch cost, 40% cpu vs io heavy task mix and creation frequency of 2.1
./hw6 -c 4 -i 5 -s 3.3 -t 40 -f 2.1